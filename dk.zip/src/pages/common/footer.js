import React from 'react'

const footer = () => {
    return (
        <div>
            <footer>
                <h1>footer</h1>
            </footer>
        </div>
    )
}

export default footer